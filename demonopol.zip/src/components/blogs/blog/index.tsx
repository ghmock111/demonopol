import Breadcrumb from "@/components/common/Breadcrumb";
import BlogArea from "./BlogArea";

const Blog = () => {
  return (
    <main>
      <Breadcrumb title="Exclusives Properties - Invest in Exclusive Real Estate with only 1 USD" />
      <BlogArea/>
    </main>
  )
}

export default Blog;
