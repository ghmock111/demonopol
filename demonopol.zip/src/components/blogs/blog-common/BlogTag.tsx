import Link from "next/link"

const tag: string[] = [
   "DeMonopol",
   "real estate",
   "blockchain",
   "tokenization",
   "NFTs",
   "DeFi",
   "gamification",
   "AI valuation",
   "crypto investments",
   "real estate simulator",
   "property fractionation",
   "MONO token",
   "community engagement",
   "property submission",
   "liquidity",
   "marketplace",
   "educational platform",
   "Decentralized Finance",
   "real estate market",
   "tokenomics",
   "fractional ownership",
   "property investment",
   "digital assets",
   "investment democratization",
   "platform governance",
   "crypto lending",
   "real estate tech",
   "user-generated content",
   "property validation",
   "market transparency",
   "investor access",
   "ICO",
   "ICO presale",
   "strategic rounds",
   "seed sale",
   "private sale",
   "community rounds",
   "airdrop",
   "token sale",
   "investment rounds",
   "fundraising",
   "pre-ICO",
   "token launch"
 ];
 
const BlogTag = () => {
   return (
      <div className="blog-widget">
         <h4 className="widget-title">Tags</h4>
         <div className="sidebar-tag-list">
            <ul className="list-wrap">
               {tag.map((tag, i) => (<li key={i}><Link href="#">{tag}</Link></li>))}
            </ul>
         </div>
      </div>
   )
}

export default BlogTag
