import Link from "next/link";

interface DataType {
   id: number;
   title: string;
   count: string;
}
const category_data: DataType[] = [
   { id: 1, title: "Long Term Renting", count: "06" }, { id: 2, title: "Tourism Renting", count: "06" },
   { id: 3, title: "Luxury Housing", count: "06" }, { id: 4, title: "Project on Plan", count: "06" },
   { id: 5, title: "***** ****", count: "06" }, { id: 6, title: "******** *******", count: "06" },
]
const BlogCategory = () => {
   return (
      <div className="blog-widget">
         <h4 className="widget-title">Properties Types</h4>
         <div className="sidebar-cat-list">
            <ul className="list-wrap">
               {category_data.map((category, index) => (
                  <li key={index}><Link href="#">{category.title} <span>{category.count}</span></Link></li>
               ))}
            </ul>
         </div>
      </div>
   )
}

export default BlogCategory
