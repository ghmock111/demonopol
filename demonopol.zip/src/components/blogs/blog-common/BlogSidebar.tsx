"use client"
import Link from "next/link"
import BlogCategory from "./BlogCategory"
import BlogRcPost from "./BlogRcPost"
import BlogTag from "./BlogTag"

const BlogSidebar = () => {
   return (
      <div className="col-lg-4">
         <aside className="blog-sidebar">
            <div className="blog-widget">
               <h4 className="widget-title">Find Exclusives Properties</h4>
               <div className="sidebar-search">
                  <form onSubmit={(e) => e.preventDefault()}>
                     <input type="text" placeholder="Search your keyword" />
                     <button type="submit"><i className="fas fa-search"></i></button>
                  </form>
               </div>
            </div>
            <BlogCategory />
            <BlogRcPost />
            <BlogTag/>
         </aside>
      </div>
   )
}
export default BlogSidebar
