import Breadcrumb from "@/components/common/Breadcrumb"
import BlogDetailsArea from "./BlogDetailsArea"

const BlogDetails = () => {
  return (
    <main>
      <Breadcrumb title="Properties Details - Invest in Exclusive Real Estate with only 1 USD" />
      <BlogDetailsArea/>
    </main>
  )
}

export default BlogDetails
