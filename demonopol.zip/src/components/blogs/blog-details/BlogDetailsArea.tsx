import Image, { StaticImageData } from "next/image";
import Link from "next/link";
import BlogSidebar from "../blog-common/BlogSidebar";
import blog_data from "@/data/BlogData"
import PropertyArea from "@/components/home/PropertyArea";

import blogThumb_1 from "@/assets/img/blog/blog_details.jpg";
import blogThumb_2 from "@/assets/img/blog/blog_details02.jpg";
import blogThumb_3 from "@/assets/img/blog/blog_details03.jpg";
import blogAvatar_1 from "@/assets/img/blog/blog_author01.png";
import blogAvatar_2 from "@/assets/img/blog/avatar.png";



interface ContentData {
   title_1: string;
   desc_1: JSX.Element;
   desc_2: JSX.Element;
   desc_3: JSX.Element;
   desc_4: JSX.Element;
   desc_5: JSX.Element;
   desc_6: JSX.Element;
   desc_7: JSX.Element;
   desc_8: JSX.Element;
   desc_9: JSX.Element;
   social_icon: string[];
   img?: StaticImageData;
}
const content_data: ContentData = {
   title_1: "ICO Success TEST Realizing the Potential of Token Sales",
   desc_1: (<> 
      <div className="luxury-property projections-list list-wrap padd">
        <h1 className="title">Luxurious Apartment for Sale</h1>
        <p className="price luxury-property">Price: $3,000,000</p>
        <p className="address luxury-property">Area: Marbella, Benahavis, SPAIN</p>
  
        <div className="luxury-property">
          <p className="luxury-property">
            Discover the epitome of luxury living in this exquisite apartment, valued at $3,000,000, situated in the prestigious area of Marbella, Benahavis. This residence offers breathtaking views of the Mediterranean Sea and is designed in a sophisticated 3D-rendered style, featuring modern furniture and dark matte finishes that exude elegance and refinement.
          </p>
          
          <h3>Interior Features:</h3>
          <ul className="features-list">
            <li>🌅 Spacious Living Area: An open-concept living room with floor-to-ceiling windows that offer stunning sea views. Furnished with contemporary pieces, creating a perfect blend of comfort and style.</li>
            <li>🍳 Gourmet Kitchen: A state-of-the-art kitchen equipped with top-of-the-line appliances, including a Sub-Zero refrigerator, Wolf oven, and a sleek induction cooktop. Quartz countertops and custom cabinetry complete this chef's dream kitchen.</li>
            <li>🛏️ Master Suite: A luxurious master bedroom with a walk-in closet and an en-suite bathroom. The bathroom features a double vanity, a soaking tub, and a rain shower, all with premium fixtures and finishes.</li>
            <li>🛌 Additional Bedrooms: Two additional spacious bedrooms with ample closet space and large windows that provide natural light and stunning views.</li>
            <li>🛁 Bathrooms: Three elegantly designed bathrooms with high-end finishes, including marble countertops and designer tiles.</li>
            <li>💻 Home Office: A dedicated home office space with custom built-in desks and shelving, perfect for remote work or study.</li>
            <li>🏠 Smart Home Features: Integrated smart home technology for lighting, climate control, and security systems, providing convenience and peace of mind.</li>
          </ul>
          
          <h3>Amenities:</h3>
          <ul className="amenities-list">
            <li>🌴 Private Terrace: A large private terrace with panoramic sea views, ideal for outdoor dining and entertaining.</li>
            <li>💪 Fitness Center: Access to a state-of-the-art fitness center equipped with the latest exercise machines and free weights.</li>
            <li>🏊 Swimming Pool: A heated indoor swimming pool for year-round enjoyment.</li>
            <li>👨‍💼 24/7 Concierge Service: Professional concierge services available around the clock to assist with your needs.</li>
            <li>🚗 Secure Parking: Two reserved parking spaces in a secure, underground garage.</li>
            <li>🛋️ Lounge Area: A beautifully designed residents' lounge with comfortable seating, a fireplace, and a bar area.</li>
          </ul>
          
          <h3>Location:</h3>
          <ul className="location-list">
            <li>📍 Prime Location: Situated in the exclusive area of Benahavis, Marbella, offering easy access to the best shopping, dining, and entertainment options.</li>
            <li>🌅 Scenic Views: Enjoy unparalleled views of the Mediterranean Sea and the surrounding landscape.</li>
            <li>🚇 Transportation: Conveniently located near public transportation and major highways, providing quick and easy access to all parts of the Costa del Sol.</li>
          </ul>
          
          <h6 className="outro luxury-property">
            This luxurious apartment offers a lifestyle of unparalleled comfort and sophistication. Don’t miss the opportunity to make this extraordinary residence your new home.
          </h6>
        </div>
      </div>
    </>),
   desc_2: (<>TEST 2 g their ICOs. From decentralized finance (DeFi) platforms that have transformed the traditional banking system to blockchain-based solutions addressing real-world challenges, these success stories demonstrate the power.</>),
   desc_3: (<>TEST 3 g their ICOs. From decentralized finance (DeFi) platforms that have transformed the traditional banking system to blockchain-based solutions addressing real-world challenges, these success stories demonstrate the power.</>),
   desc_4: (<>TEST 4 oin us on this journey as we explore the fascinating world of ICO success stories and the incredible potential they hold.</>),
   desc_5: (<>TEST 15 rom failure.</>),
   desc_6: (<><PropertyArea /></>),
   desc_7: (<>TEST 17ting traditional industries and paving the way for revolutionary solutions. From decentralized applications (DApps) that have reshaped digital ecosystems to blockchain platforms revolutionizing supply chain management, these success stories demonstrate the power of ICOs to propel ideas into reality.</>),
   desc_8: (<>TEST 18he challenges they faced, the strategies they employed, and the lessons they learned along the way. Whether you&apos;re an investor seeking inspiration or an entrepreneur entrepreneur considering an ICO, these stories.</>),
   desc_9: (<>TEST 19ars of experience as an award-winning Creative Director/Art for clients.</>),
   social_icon: ["fab fa-facebook-f", "fab fa-linkedin-in", "fab fa-twitter", "fab fa-instagram",],

}
const { title_1, desc_1, desc_2, desc_3, desc_4, desc_5, social_icon, desc_6, desc_7, desc_8, desc_9, img } = content_data;

const BlogDetailsArea = ({ single_blog }: any) => {
   return (
      <section className="blog-details-area pt-140 pb-140">
         <div className="container">
            <div className="row">
               <div className="col-lg-8">
                  <div className="blog-details-wrap">
                     <div className="blog-details-thumb">
                        {single_blog?.thumb ? <Image src={single_blog.thumb} alt="image" /> : <Image src={blogThumb_1} alt="image" />}
                     </div>
                     <div className="blog-details-content">
                        <div className="blog-meta">
                        <div className="progress-wrap">
                              <div className="progress" role="progressbar">
                              <div className="progress-bar" style={{ width: "86%" }}></div>
                         </div>
                               <h6 className="progress-title"> Currently Achieved {single_blog?.price}  <span>Value of the Property: {single_blog?.price}</span></h6>
                          </div>
                           <ul className="list-wrap">
                              <li className="blog-author">
                                 <Link href="/blog-details">{single_blog?.author_avatar ? <Image src={single_blog?.author_avatar} alt="" /> : <Image src={blogAvatar_1} alt="" />}
                                    {single_blog?.author_name ? single_blog.author_name : "Stacey Moore"}
                                 </Link>
                              </li>
                              <li><i className="far fa-clock"></i>{single_blog?.date ? single_blog.date : "2023/03/15"}</li>
                              <li><Link href="/blog-details"><i className="far fa-comment"></i>{single_blog?.comment ? single_blog.comment : "07"}</Link></li>
                              <li><i className="far fa-eye"></i>{single_blog?.views ? single_blog.views : "1,752 Owners"}</li>
                              <li><i className='fas fa-dollar-sign'></i>{single_blog?.price ? single_blog.price : "Il y a une erreur"}</li>
                           </ul>
                        </div>
                        <h2 className="title projections-list">{single_blog?.title ? single_blog.title : title_1}</h2>
                        <blockquote>
                        <div className="row justify-content-evenly padd projections-list">
                              <div className="col-lg-2"><Image src={single_blog?.featureFlat1} alt="Number of bathrooms " /> <h6>{single_blog?.bath} bathrooms</h6></div>
                              <div className="col-lg-2"><Image src={single_blog?.featureFlat2} alt="Number of Rooms " /> <h6> {single_blog?.room}  rooms </h6></div>
                              <div className="col-lg-2"><Image src={single_blog?.featureFlat3} alt="Property Size" />  <h6>{single_blog?.size}   Available</h6></div>
                              <div className="col-lg-2"><Image src={single_blog?.featureFlat4} alt="Property Type" />  <h6> {single_blog?.propertyType} </h6> </div>
                              </div>  
                        </blockquote>
                        {desc_1}
                        <div className="blog-details-inner-img">
                           <div className="row">
                              <div className="col-md-6">
                                 <Image src={blogThumb_2} alt="" />
                              </div>
                              <div className="col-md-6">
                                 <Image src={blogThumb_3} alt="" />
                              </div>
                           </div>
                        </div>
                        <PropertyArea />
                     </div>
                  </div>
                  <div className="salesPunchline">
                              <blockquote>
                              </blockquote>
                  </div>
               </div>
               <BlogSidebar/>
            </div>
         </div>
      </section>
   )
}

export default BlogDetailsArea
