import Image, { StaticImageData } from "next/image"

import contentImg_1 from "@/assets/img/images/contact01.png";
import contentImg_2 from "@/assets/img/images/contact02.png";
import contentImg_3 from "@/assets/img/images/contact03.png";

interface DataType {
   id: number;
   img: StaticImageData;
   title: string;
   info: JSX.Element;
}

const contact_data: DataType[] = [
   {
      id: 1,
      img: contentImg_3,
      title: "Real Estates Professional Partners",
      info: (
         <>
            Professional partners are established real estate professionals and firms who collaborate with us to enhance the platform's credibility, quality, and growth.
            <ul>
               <li>Property Submission</li>
               <li>Market Expertise</li>
               <li>Credibility and Trust</li>
               <li>Growth Acceleration</li>
               <li>Advisory Role</li>
            </ul>
         </>
      ),
   },
   {
      id: 2,
      img: contentImg_2,
      title: "Key Opinion Leaders (KOLs)",
      info: (
         <>
            KOLs are influential individuals in the real estate and blockchain communities who promote DeMonopol, engage with users, and provide valuable feedback to enhance the platform.
            <ul>
               <li>Promotion and Outreach</li>
               <li>Community Engagement</li>
               <li>Feedback and Improvement</li>
               <li>Educational Content</li>
               <li>Brand Ambassadors</li>
            </ul>
         </>
      ),
   },
   {
      id: 3,
      img: contentImg_1,
      title: "Alpha Programs for Exclusive Access",
      info: (
         <>
            Alpha Programs attract and reward early users with special access to platform features, limited-edition NFTs, and unique benefits.
            <ul>
               <li>Exclusive Access</li>
               <li>Limited-Edition NFTs</li>
               <li>Feedback and Improvement</li>
               <li>Community Building</li>
               <li>Rewards and Incentives</li>
            </ul>
         </>
      ),
   },
]

const ContactArea = () => {
   return (
      <section className="contact-area pt-140 pb-140">
         <div className="container">
            <div className="contact-info-wrap">
               <div className="row justify-content-center">
                  {contact_data.map((item) => (
                     <div key={item.id} className="col-xl-4 col-lg-4 col-md-6">
                        <div className="contact-info-item">
                        <div className="features-img">
                           <Image src={item.img} alt="Partnerships Icons" className="forceCenterImg" />
                        </div>
                           <div className="content">
                              <h6 className="title">{item.title}</h6>
                              <p>{item.info}</p>
                           </div>
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         </div>
      </section>
   )
}

export default ContactArea
