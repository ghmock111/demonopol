import Breadcrumb from "../common/Breadcrumb"
import ContactArea from "./ContactArea"

const Contact = () => {
   return (
      <main>
         <Breadcrumb title="KOLs, Partners, and Alpha contacts" />
         <ContactArea/>
      </main>
   )
}

export default Contact
