import Image, { StaticImageData } from "next/image"
import Link from "next/link";

import featureImg_1 from "@/assets/img/images/features_img01.png";
import featureImg_2 from "@/assets/img/images/features_img02.png";
import featureImg_3 from "@/assets/img/images/features_img03.png";
import featureImg_4 from "@/assets/img/images/features_img04.png";

interface DataType {
   id: number;
   title: JSX.Element;
   desc: JSX.Element;
   img: StaticImageData;
}
const feature_data: DataType[] = [
   {
      id: 1,
      title: (<>Accessible Fractional Real Estate Investment:</>),
      desc: (<>Invest from $1 in fractional properties using blockchain.</>),
      img: featureImg_1,
   },
   {
      id: 2,
      title: (<>Liquid Real Estate Marketplace:</>),
      desc: (<>Easily buy and sell property fractions, enhancing market liquidity.</>),
      img: featureImg_2,
   },
   {
      id: 3,
      title: (<>Strategic Partnerships: </>),
      desc: (<>Collaborate with renowned real estate professionals for reliable and credible investment opportunities.</>),
      img: featureImg_3,
   },
   {
      id: 4,
      title: (<> Community-Driven Property Management:</>),
      desc: (<>Utilize DAO for transparent and collaborative property management decisions.</>),
      img: featureImg_4
   },
]
const FeatureOne = () => {
   return (
      <section id="feature" className="features-area pt-140 pb-110">
         <div className="container">
            <div className="row justify-content-center">
               <div className="col-lg-10">
                  <div className="section-title text-center mb-70">
                     <h2 className="title">Accessible and Decentralized Real Estate Investment through Blockchain Innovation </h2>
                  </div>
               </div>
            </div>
            <div className="row">
               {feature_data.map((item) => (
                  <div key={item.id} className="col-lg-6">
                     <div className="features-item">
                        <div className="features-content">
                           <h2 className="title"><Link href="#!">{item.title}</Link></h2>
                           <p>{item.desc}</p>
                        </div>
                        <div className="features-img">
                           <Image src={item.img} alt="" />
                        </div>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </section>
   )
}

export default FeatureOne
