"use client"
import { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import 'chart.js/auto';
import Image from 'next/image';

import chartImg from "@/assets/img/images/chart_img.png"

const tab_title: string[] = ["Token Allocation", "Airdrop Distribution"]; // ,"Token Distribution"
const chart_List_1: string[] = ["Seed Sales: 5% (50,000,000 MONO) - Value: 0.004 USD", "Private Sales: 30% (300,000,000 MONO) - 9 rounds with price increment starting at 0.005 USD ", "Community Rounds: 20% (200,000,000 MONO) - Price: 0.01 USD", "Airdrop: 15% (150,000,000 MONO) - Approx. value: 1.5M USD", "Project Treasury: 30% (300,000,000 MONO) - For dex liquidity, advisors, business development, market making, CEX listings"]
const chart_List_2: string[] = ["Professional Partners 20%", "Key Opinion Leaders (KOLs) 20%", "Demonopol Users 20%", "Community Gringing: 20%", "Business Development & Hackathons: 20%"]
// const chart_List_3: string[] = ["Professional Partners 20%", "Key Opinion Leaders (KOLs) 20%", "Demonopol Users 20%", "Community Gringing: 20%", "Business Development & Hackathons: 20%"]

const ChartArea = () => {

   const [activeTab, setActiveTab] = useState(0);

   // Handle tab click event
   const handleTabClick = (index: any) => {
      setActiveTab(index);
   };


   const chartData = [
      [5, 30, 20, 15, 30], // Funding Allocation percentages
      [20, 20, 20, 20, 20]  // Token Distribution percentages
   ];

   const data = {
      // labels: ["Contingency", "Business Development", "Investor", "Poland", "Legal & Regulation", "Czech Republic"],
      datasets: [
         {
            label: 'Allocations',
            data: chartData[activeTab],
            backgroundColor: ["#44A08D", "#136F84", "#0B446D", "#033356", "#012641", "#191F28"]
         }
      ],
   };

   return (
      <div id="chart" className="chart-area pt-140">
         <div className="container">
            <div className="chart-inner-wrap">
               <div className="row align-items-center">
                  <div className="col-lg-6">
                     <div className="chart-wrap">
                        <div className="chart">
                           <div id="doughnutChart">
                              {chartData[activeTab] && <Doughnut data={data} />}
                           </div>
                        </div>
                        <div className="chart-tab">
                           <ul className="nav nav-tabs" id="myTab" role="tablist">
                              {tab_title.map((tab, index) => (
                                 <li key={index} className="nav-item">
                                    <button onClick={() => handleTabClick(index)}
                                       className={activeTab === index ? 'nav-link active' : ' nav-link'}>{tab}
                                    </button>
                                 </li>
                              ))}
                           </ul>
                           <div className="tab-content" id="myTabContent">
                              <div className={`tab-pane fade ${activeTab === 0 ? 'show active' : ''}`} id="description">
                                 <div className="chart-list">
                                    <ul className="list-wrap">
                                       {chart_List_1.map((list, index) => (<li key={index}>{list}</li>))}
                                    </ul>
                                 </div>
                              </div>
                              <div className={`tab-pane fade ${activeTab === 1 ? 'show active' : ''}`} id="description">
                                 <div className="chart-list">
                                    <ul className="list-wrap">
                                       {chart_List_2.map((list, i) => (<li key={i}>{list}</li>))}
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-6">
                     <div className="right-side-content">
                     <Image src={chartImg} alt="" />
                        <ul className="list-wrap">
                           <li><span>1</span>Token Symbol = MONO </li>
                           <li><span>2</span>Project = RWA, DAO, PUBLIC GOOD, SocFi</li>
                           <li><span>3</span>Omnichain Protocol = ETH, layers 2, SUI, SOLANA </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   )
}

export default ChartArea
