import Image, { StaticImageData } from "next/image"

import featuresImg_1 from "@/assets/img/images/features_two_img01.png";
import featuresImg_2 from "@/assets/img/images/features_two_img02.png";
import featuresImg_3 from "@/assets/img/images/features_two_img03.png";
import featuresImg_4 from "@/assets/img/images/features_two_img04.png";
import featuresImg_5 from "@/assets/img/images/features_two_img05.png";
import featuresImg_6 from "@/assets/img/images/features_two_img06.png";
import featuresImg_7 from "@/assets/img/images/features_two_img07.png";





import featuresTitleImg_1 from "@/assets/img/images/title_img01.jpg";
import featuresTitleImg_2 from "@/assets/img/images/title_img02.jpg";

import featuresShape_1 from "@/assets/img/images/features_shape01.png";
import featuresShape_2 from "@/assets/img/images/features_shape02.png";

interface DataType {
   id: number;
   title: string;
   img: StaticImageData;
}

const feature_data: DataType[] = [
   {
      id: 1,
      title: "Governance Participation Using MONO Token.",
      img: featuresImg_1
   },
   {
      id: 2,
      title: "Rentability & Control over Real Estate investment",
      img: featuresImg_2
   },
   {
      id: 3,
      title: "Validate/Submit Properties with MONO",
      img: featuresImg_3
   },   {
      id: 4,
      title: "Exclusive Benefits for MONO Stakers: Stake MONO tokens to unlock exclusive perks such as premium investment and events.",
      img: featuresImg_4
   }
   ,   {
      id: 5,
      title: "Integrated Social Finance (SocFi) Network: Connect with a network of investors and industry players for collaborative growth.",
      img: featuresImg_5
   }
   ,   {
      id: 6,
      title: "Decentralized Property Management via DAO: Participate in transparent and community-driven property management using a DAO.",
      img: featuresImg_6
   }
   ,   {
      id: 7,
      title: "Revenue Sharing for MONO Holders/Stakers",
      img: featuresImg_7
   }
]

const FeatureTwo = () => {
   return (
      <section className="features-area-two features-bg" style={{ backgroundImage: `url(/assets/img/bg/features_bg.png)` }}>
         <div className="container">
            <div className="features-inner-wrap">
               <div className="features-item-wrap">
                  <div className="row justify-content-center">
                     {feature_data.map((item) => (
                        <div key={item.id} className="col-lg-4 col-md-6">
                           <div className="features-item-two">
                              <div className="features-img-two">
                                 <Image src={item.img} alt="" />
                              </div>
                              <div className="features-content-two">
                                 <h2 className="title">{item.title}</h2>
                              </div>
                           </div>
                        </div>
                     ))}
                 </div>
               </div>
               <div className="row">
                  <div className="col-lg-12">
                     <div className="section-title section-title-two text-center">
                        <h2 className="title">Maximize Your Real Estate Investment Potential with MONO Token. The ideal and easy profits saver Dapp</h2>
                     </div>
                  </div>
               </div>
               <div className="features-line-shape"></div>
            </div>
         </div>
         <div className="features-shape-wrap">
            <Image src={featuresShape_1} alt="" className="alltuchtopdown" />
            <Image src={featuresShape_2} alt="" className="leftToRight" />
         </div>
      </section>
   )
}

export default FeatureTwo
