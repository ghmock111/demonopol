"use client"
import { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import 'chart.js/auto';
import { StaticImageData } from "next/image";
import blog_data from "@/data/BlogData"  // BLOG DATE TO CREATE DYNAMIC INFOS


import featureFlat1 from  "@/assets/img/blog/featuresimg1.png"
import featureFlat2 from  "@/assets/img/blog/featuresimg2.png"
import featureFlat3 from  "@/assets/img/blog/featuresimg3.png"
import featureFlat4 from  "@/assets/img/blog/featuresimg4.png"

const tab_title: string[] = ["Property Financial Details", "Property Plans & Documents", "Property Ownership Map" , "Votes Ongoing", "Agency Expert Review"]; 
// const chart_List_3: string[] = ["Professional Partners 20%", "Key Opinion Leaders (KOLs) 20%", "Demonopol Users 20%", "Community Gringing: 20%", "Business Development & Hackathons: 20%"]

const PropertyArea = () => {


   const [activeTab, setActiveTab] = useState(0);

   // Handle tab click event
   const handleTabClick = (index: any) => {
      setActiveTab(index);
   };

   return (
         <div className="container padd">
               <div className="row align-items-center">
                     <div className="chart-wrap">
                        <div className="chart-tab">
                           <ul className="nav nav-tabs" id="myTab" role="tablist">
                              {tab_title.map((tab, index) => (
                                 <li key={index} className="nav-item">
                                    <button onClick={() => handleTabClick(index)}
                                       className={activeTab === index ? 'nav-link active' : ' nav-link'}>{tab}
                                    </button>
                                 </li>
                              ))}
                           </ul>
                           <div className="tab-content" id="myTabContent">
                              <div className={`tab-pane fade ${activeTab === 0 ? 'show active' : ''}`} id="description">
                              <div className="financial-projections">
                              <h2 className="title projections-list">Financial Projections</h2>
                                          <ul className="projections-list list-wrap"> 
                                          <li><h6>Projected Annual Return: 12.85%</h6></li>
                                          <li><h6>Rental Yield: 3.95%</h6></li>
                                          <li><h6>Projected Appreciation: 6.0%</h6></li>
                                          <li><h6>Total Property Value: $3,000,000</h6></li>
                                          <li><h6>Protocol Management fees : 5%</h6> </li>
                                          <li><h6>Vendor Comission: 2%</h6></li>
                                          <li><h6>Property Management Pool: $45,000</h6></li>
                                          <li><h6>Projected Annual Rental Income: $118,500</h6></li>
                                          <li><h6>Property Taxes: $35,000 </h6></li>
                                          <li><h6>Property Management: $18,000</h6></li>
                                          <li><h6>Annual Estimated Income: $83,500</h6></li>
                                          </ul>
                                       </div> 
                              </div>
                              <div className={`tab-pane fade ${activeTab === 1 ? 'show active' : ''}`} id="description">
                              <div className="document-table-container padd projections-list">
      <h2 id="tabl"> Documents available for this property</h2>
      <table className="document-table padd projections-list">
        <thead>
          <tr>
            <th>S.No</th>
            <th>Documents</th>
            <th>Description</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {blog_data.map(( blog ) => (
            <tr key={blog.id}>
              <td>{blog.id}</td>
              <td>{blog.id}</td>
              <td>{blog.id}</td>
              <td>
                <a href="{blog.id}" className="action-link">Download</a>
                <a href="" className="action-link">View</a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>   </div>
                              <div className={`tab-pane fade ${activeTab === 2 ? 'show active' : ''}`} id="description">
                              </div>
                              </div>
                           </div>
                        </div>
                  </div>
         </div>
      </div>
   )
}

export default PropertyArea
