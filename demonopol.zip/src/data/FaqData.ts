
const faq_data = [
   {
      id: 1,
      question: " What is Demonopol?",
      answer: "DeMonopol is a decentralized platform revolutionizing real estate investment by making it accessible, gamified, and transparent through blockchain technology.",
      showAnswer: false,
   },
   {
      id: 2,
      question: "What is the mission of Demonopol?",
      answer: "Our mission is to democratize real estate investment, allowing anyone to invest with as little as 1 USD, and to create an ecosystem where users can learn, grow, and actively participate in the market.",
      showAnswer: false,
   },
   {
      id: 3,
      question: "How does DeMonopol ensure security and transparency?",
      answer: "DeMonopol uses blockchain technology to ensure secure, transparent, and immutable transactions. All property data, transactions, and evaluations are publicly accessible on the blockchain.",
      showAnswer: false,
   },
   {
      id: 4,
      question: " How can I start investing in real estate through DeMonopol",
      answer: "Simply create an account, purchase MONO tokens, and choose from a variety of fractional real estate investments starting from just 1 USD.",
      showAnswer: false,
   },
   {
      id: 5,
      question: "Can I submit properties to be listed on DeMonopol?",
      answer: "Yes, both individual users and professional real estate actors will be able to submit properties for tokenization and listing on our platform.",
      showAnswer: false,
   },{
      id: 6,
      question: "How can I become a professional partner or KOL?",
      answer: "Interested parties can apply at contact@demonopol.com. We review applications and onboard partners who align with our mission and values.",
      showAnswer: false,
   },{
      id: 7,
      question: "What role do Professional Partners play in DeMonopol?",
      answer: "They submit high-quality properties for tokenization, provide market expertise, add credibility and trust to the platform, accelerate growth, manages properties and serve as Real Estates Advisors.",
      showAnswer: false,
   },{
      id: 8,
      question: "Who are Key Opinion Leaders (KOLs) in DeMonopol?",
      answer: "KOLs are influential individuals in the real estate and blockchain communities who promote DeMonopol, engage with users, and provide valuable feedback to enhance the platform.",
      showAnswer: false,
   },{
      id: 9,
      question: "How can I purchase MONO tokens?",
      answer: "MONO tokens can be purchased during our seed, private, and community sales, and will be available on major cryptocurrency exchanges after the Token Generation Event (TGE).",
      showAnswer: false,
   },
   {
      id: 9,
      question: "What is vMONO and why did I receive it?",
      answer: "vMONO is our pre-token for proof-of-concept (POC) purposes. You received it to test our platform's features as we release them, allowing you to experience and provide feedback on the functionality before the official launch.",
      showAnswer: false,
   },
   
];

export default faq_data;