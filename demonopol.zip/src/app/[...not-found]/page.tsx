import Error from "@/components/error/Index";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
   title: "404 error || Oups, we are out of the way to join Demonopol!",
};

export async function generateStaticParams() {
    return [{ 'not-found': ["404"]}];
}

const index = () => {
   return (
      <Wrapper>
         <Error />
      </Wrapper>
   )
}

export default index
