import Home from "@/components/home";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
  title: "DeMonopol, RWA PUBLIC GOOD project Omnichain, Dematerialize Real Estate Economy",
};
const index = () => {
  return (
    <Wrapper>
      <Home />
    </Wrapper>
  )
}

export default index