import Contact from "@/components/contact";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
   title: "Alpha KOLs and Parteners Program - Join the revolution of Real Estate through RWA, Public Good project.",
};
const index = () => {
   return (
      <Wrapper>
         <Contact />
      </Wrapper>
   )
}

export default index