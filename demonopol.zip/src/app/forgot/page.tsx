import ResetPassWord from "@/components/reset-password";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
   title: "Reset PassWord Demonopol - Leading the Public Good Revolution",
};
const index = () => {
   return (
      <Wrapper>
         <ResetPassWord />
      </Wrapper>
   )
}

export default index