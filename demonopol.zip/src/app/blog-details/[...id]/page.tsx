import BlogDetailsArea from "@/components/blogs/blog-details/BlogDetailsArea";
import Breadcrumb from "@/components/common/Breadcrumb";
import blog_data from "@/data/BlogData";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
   title: "Properties Details - Invest in Exclusive Real Estate with only 1 USD",
};

export async function generateStaticParams() {
    return blog_data.map((item) => ({
        id: [item.id.toString()],
    }));
}

const index = ({ params }: { params: { id: string } }) => {

   const single_blog = blog_data.find((item) => Number(item.id) === Number(params.id));

   return (
      <Wrapper>
         <main>
            <Breadcrumb title="Properties Details" />
            <BlogDetailsArea  single_blog={single_blog} key={single_blog?.id} />
         </main>
      </Wrapper>
   )
}

export default index