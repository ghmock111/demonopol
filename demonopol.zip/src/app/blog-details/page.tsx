import BlogDetails from "@/components/blogs/blog-details";
import Wrapper from "@/layout/Wrapper";

export const metadata = {
   title: "Properties Details - Invest in Exclusive Real Estate with only 1 USD",
};
const index = () => {
   return (
      <Wrapper>
         <BlogDetails />
      </Wrapper>
   )
}

export default index