import Image from "next/image";
import Link from "next/link";

import logo_1 from "@/assets/img/logo/logo.png";

const HeaderOffcanvas = ({ offCanvas, setOffCanvas }: any) => {
   return (
      <>
         <div className={`${offCanvas ? "offcanvas-menu-visible" : ""}`}>
            <div className={`extra-info ${offCanvas ? "active" : ""}`}>
               <div className="close-icon menu-close">
                  <button onClick={() => setOffCanvas(false)}><i className="far fa-window-close"></i></button>
               </div>
               <div className="logo-side mb-30">
                  <Link href="/"><Image src={logo_1} alt="Logo" /></Link>
               </div>
               <div className="side-info mb-30">
                  <div className="contact-list mb-30">
                     <h4>Transforming Properties into Profits or<br></br> <br></br>Profits into Properties: Welcome to the DeMonopol Revolution!</h4>
                  </div>
                  <div className="contact-list mb-30">
                     <h4>Own a Piece of Tomorrow: Join the DeMonopol Alpha Program Today!</h4>
                    </div> <div className="contact-list mb-30">
                    <Link href="#"><h4>NFT ALPHA ACCESS MINTING LING AVAILABLE SOON</h4></Link>
                    </div>
               </div>
               <div className="social-icon-right mt-30">
                  <Link href="https://x.com/demonopolrwa"><i className="fab fa-xing" aria-hidden="true"></i></Link>  
                  <Link href="https://t.me/demonopolrwa"><i className="fab fa-telegram"></i></Link>
               </div>
            </div>
            <div onClick={() => setOffCanvas(false)} className={`offcanvas-overly ${offCanvas ? "active" : ""}`}></div>
         </div>
      </>
   )
}

export default HeaderOffcanvas
