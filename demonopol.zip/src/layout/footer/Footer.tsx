"use client"
import Image from "next/image";
import Link from "next/link";

import footerShape_1 from "@/assets/img/images/footer_shape01.png";
import footerShape_2 from "@/assets/img/images/footer_shape02.png";
import NewsletterForm from "@/components/forms/NewsletterForm";

interface DataType {
   id: number;
   class_name: string;
   title: string;
   footer_link: {
      link: string;
      link_title: string;
   }[]
}

const footer_data: DataType[] = [
   {
      id: 1,
      class_name: "col-xl-3 col-lg-3 col-md-4 col-sm-6",
      title: "Join our Alpha Program and mint our exclusive 3D NFT. Gain access to exlusive properties, beta features",
      footer_link: [{ link: "/contact", link_title: "Read our rules on Medium" }]
   },
   {
      id: 2,
      class_name: "col-xl-3 col-lg-2 col-md-4 col-sm-6",
      title: "Illustrated video explaining the vision of Demonopol, how it works, and what benefits it has, for users, agencies and KOLs(Blockchain and RWA)",
      footer_link: [{ link: "/contact", link_title: "Here Display the video instead of a link" }]
   },
   {
      id: 3,
      class_name: "col-xl-3 col-lg-3 col-md-4 col-sm-4",
      title: "Usefull Links",
      footer_link: [{ link: "/contact", link_title: "Parteners and KOLs Program" }, { link: "/contact", link_title: "Alpha Program" }, { link: "/blog", link_title: "Properties on Demonopol" }, { link: "/contact", link_title: "Profesional actors of Demonopol" },]
   },
]

const Footer = () => {
   return (
      <footer>
         <div className="footer-area footer-bg" style={{ backgroundImage: `url(/assets/img/bg/footer_bg.png)` }}>
            <div className="container">
               <div className="footer-top">
                  <div className="row">
                     {footer_data.map((item) => (
                        <div key={item.id} className={item.class_name}>
                           <div className="footer-widget">
                              <h4 className="fw-title">{item.title}</h4>
                              <div className="footer-link">
                                 <ul className="list-wrap">
                                    {item.footer_link.map((li, i) => (
                                       <li key={i}><Link href={li.link}>{li.link_title}</Link></li>
                                    ))}
                                 </ul>
                              </div>
                           </div>
                        </div>
                     ))}
                     <div className="col-xl-3 col-lg-4 col-sm-8">
                        <div className="footer-widget">
                           <h4 className="fw-title">Stay up to date with our newsletter</h4>
                           <div className="footer-newsletter">
                              <p>You will receive premium information about our project progress, new programs and also about Real Estates Market and Crypto Market, combined to diversivy accordingly</p>
                              <NewsletterForm/>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               
               <div className="footer-bottom">
                  <div className="row">
                     <div className="col-lg-12">
                        <div className="copyright-text">
                           <p>Demonopol the Future of Decentralized Real Estates</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div className="footer-shape-wrap">
               <Image src={footerShape_1} alt="" className="alltuchtopdown" />
               <Image src={footerShape_2} alt="" className="leftToRight" />
            </div>
         </div>
      </footer>
   )
}

export default Footer;
