"use client";

import { useEffect } from "react";
import ScrollToTop from "@/components/common/ScrollToTop";
import { ToastContainer } from "react-toastify";
import { animationCreate } from "@/utils/utils";
import { initGA, logPageView } from '@/components/anal/anal.js'; // Import the utility you created


if (typeof window !== "undefined") {
    require("bootstrap/dist/js/bootstrap");
}

const Wrapper = ({ children }: any) => {
    useEffect(() => {
        // animation
        const timer = setTimeout(() => {
            animationCreate();
        }, 100);

        initGA(); // Initialize Google Analytics
    logPageView(); // Log the initial page view

        return () => clearTimeout(timer);
    }, []);


    return <>
        {children}
        <ScrollToTop />
        <ToastContainer position="top-center" />
    </>;
}

export default Wrapper
