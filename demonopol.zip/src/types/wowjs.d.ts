declare module 'wowjs' {
  const WOW: any;
  export default WOW;
}
