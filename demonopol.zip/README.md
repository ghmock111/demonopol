This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Development

### Prerequisites

- Node.js
- npm

### Installation

Install the dependencies:
```bash
npm install
```

Run the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `tsx` files. The page auto-updates as you edit the file.

## Build and Deploy

To build the app for production, run:

```bash
npm run build
```

It will create a production build in the `out` directory. 
You can deploy the app to Hostinger by copying the contents of the `out` directory to the `public_html` directory.

To deploy the app locally, run:

```bash
npm run start
```
